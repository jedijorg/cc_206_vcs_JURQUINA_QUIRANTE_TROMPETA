package com.example.cc206_exercise_unit3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
